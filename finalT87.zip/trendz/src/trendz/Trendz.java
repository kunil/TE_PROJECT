
package trendz;
import java.sql.Connection;
import java.sql.DriverManager;
public class Trendz {

    static int cid;
    static String temp;
    static String range;
    static String month;
    static int bill_id;
    //static int bill_id2;
    static int admin_id;
    static long no;
    static int flag;
    static String level;
    static int flag2;
    public static void main(String[] args) {
        
        // TODO code application logic here
        
        try{
          
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
       // cust_form form1;
        //form1 = new cust_form();
        //form1.setVisible(true);
        
      admin form=new admin();
     form.setVisible(true);
      //  NewJFrame n1= new NewJFrame ();
        //n1.setVisible(true);
        //item_form form1;
        //form1 = new item_form();
        //form1.setVisible(true);
       
      //  product_form p1;
       // p1 = new product_form();
       // p1.setVisible(true);
     
        //cust_form c = new cust_form();
        //c.setVisible(true);
        
       //bill b = new bill();
       //b.setVisible(true);
    }
    
}